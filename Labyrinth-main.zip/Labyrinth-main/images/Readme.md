GameGraphics Version 1.1

config.json controls widget display and specifies image files to use 

Simple JSON file came from
https://code.google.com/archive/p/json-simple/downloads

