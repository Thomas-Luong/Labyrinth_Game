public interface Observer {
    void update(Object arg);
}
